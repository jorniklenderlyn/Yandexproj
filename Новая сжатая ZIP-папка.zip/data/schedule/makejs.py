import json
import os


PATH = r'C:\Users\npavlichenko\Desktop\DEV\data\schedule'


if 'schedulenamesjs.json' not in os.listdir(PATH):
    r = {'schedule': ['!start'], 'lastschedule': '!start'}
    with open(PATH + '/schedulenamesjs.json', 'w', encoding='utf-8') as file:
        json.dump(r, file)


def add_name(name):
    with open(PATH + '/schedulenamesjs.json', 'r', encoding='utf-8') as file:
        lst_names = json.load(file)['schedule']
    lst_names += [name]
    dictnames = {'schedule': lst_names, 'lastschedule': name}
    with open(PATH + '/schedulenamesjs.json', 'w', encoding='utf-8') as file:
        json.dump(dictnames, file)


def get_lastname():
    with open(PATH + '/schedulenamesjs.json', 'r', encoding='utf-8') as file:
        return json.load(file)['lastschedule']


def get_names():
    with open(PATH + '/schedulenamesjs.json', 'r', encoding='utf-8') as file:
        return json.load(file)['schedule']


if __name__ == '__main__':
    add_name('o')
    print(get_names())
