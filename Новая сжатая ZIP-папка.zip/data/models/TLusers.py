import sqlalchemy
from data.func_db.db_session import SqlAlchemyBase


class TLuser(SqlAlchemyBase):
    __tablename__ = "TLusers"

    id = sqlalchemy.Column(sqlalchemy.Integer, autoincrement=True, primary_key=True)
    Utl_id = sqlalchemy.Column(sqlalchemy.Text)
    Uclass = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Uusername = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Uitcube_section = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Umailing_schedule = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
    Umailing_events = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
