import datetime

from flask import jsonify
from flask_restful import Resource, abort

from . import db_session
from .events import Event


def abort_if_event_not_found(event_id):
    session = db_session.create_session()
    event = session.query(Event).get(event_id)
    if not event:
        abort(404, message=f"Event {event_id} not found")


class EventsListResource(Resource):
    def get(self):
        db_session.global_init("kcodbforbots")
        session = db_session.create_session()
        events = session.query(Event).all()
        print(events)
        return jsonify({'events': [item.to_dict() for item in events]})


class EventResource(Resource):
    def get(self, event_id):
        abort_if_event_not_found(event_id)
        session = db_session.create_session()
        event = session.query(Event).get(event_id)
        return jsonify({'events': event.to_dict()})


class EventsRange(Resource):
    def get(self, range):  # range в формате Y-m-d:Y-m-d
        dates = range.split(':')
        date_1 = datetime.datetime.strptime(dates[0], '%Y-%m-%d')
        date_2 = datetime.datetime.strptime(dates[1], '%Y-%m-%d')
        session = db_session.create_session()
        events = session.query(Event).filter(Event.Edate_of_start_event >= date_1).filter(Event.Edate_of_finish_event <= date_2)
        return jsonify({'events': [item.to_dict() for item in events]})




