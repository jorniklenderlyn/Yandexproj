import sqlalchemy
import sqlalchemy.orm as orm
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
import sqlalchemy.ext.declarative as dec

SqlAlchemyBase = dec.declarative_base()

__factory = None


USER = 'root'
PASSWORD = 'vhjkghkghk'


def create_db(db_file):
    engine = sqlalchemy.create_engine(f'mysql+mysqlconnector://{USER}:{PASSWORD}@localhost')  # connect to server
    engine.execute(f"CREATE DATABASE {db_file.strip()}")  # create db


def delete_db(db_file):
    engine = sqlalchemy.create_engine(f'mysql+mysqlconnector://{USER}:{PASSWORD}@localhost')  # connect to server
    engine.execute(f"DROP DATABASE {db_file.strip()}")  # delete db


def global_init(db_file):
    global __factory

    if __factory:
        return
    e = create_engine(f"mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/{db_file.strip()}", echo=False)
    __factory = orm.sessionmaker(bind=e)
    from . import __all_models

    SqlAlchemyBase.metadata.create_all(e)


def create_session() -> Session:
    global __factory
    return __factory()


if __name__ == '__main__':
    #delete_db('kcodbforbots')
    #create_db('kcodbforbots')
    #engine = sqlalchemy.create_engine(f'mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/kcodbforbots')  # connect to server
    #engine.execute("ALTER TABLE TLusers ADD Uusername TEXT NULL;")
    #engine.execute("ADD Uphnumber TEXT NULL;")  # create d
    #engine = sqlalchemy.create_engine(f'mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/kcodbforbots')  # connect to server
    #engine.execute("DELETE FROM TLusers WHERE id = 13;")
    pass
