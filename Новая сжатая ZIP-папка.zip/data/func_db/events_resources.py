import datetime

import sqlalchemy
from flask import jsonify
from flask_restful import Resource, abort
from requests import get

import sys
sys.path.insert(1, r'C:\Users\npavlichenko\Desktop\DEV')

from . import db_session
from data.models.events import Event

USER = 'root'
PASSWORD = ''


def abort_if_event_not_found(event_id):
    session = db_session.create_session()
    event = session.query(Event).get(event_id)
    if not event:
        abort(404, message=f"Event {event_id} not found")


rows = ['id', 'date_of_publiction', 'Etitle_of_event', 'Edate_of_start_event', 'Edate_of_finish_event',
        'Estatus_of_school', 'Estatus_of_speciality', 'Estatus_of_class', 'Ephoto', 'Edescription']


class EventsListResource(Resource):
    def get(self):
        try:
            engine = sqlalchemy.create_engine(f"mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/kcodbforbots", echo=False)
            responce = engine.execute(f"SELECT * FROM events").fetchall()
            events = []
            for i in range(len(responce)):
                event = {}
                for j in range(len(rows)):
                    event[rows[j]] = responce[i][j]
                events.append(event)
            return jsonify({'events': [item for item in events]})

        except Exception as e:
            print(e)


class EventResource(Resource):
    def get(self, event_id):
        abort_if_event_not_found(event_id)
        try:
            engine = sqlalchemy.create_engine(f"mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/kcodbforbots", echo=False)
            responce = engine.execute(f"SELECT * FROM events WHERE id={event_id}").fetchall()
            events = []
            for i in range(len(responce)):
                event = {}
                for j in range(len(rows)):
                    event[rows[j]] = responce[i][j]
                events.append(event)
            return jsonify({'events': [item for item in events]})

        except Exception as e:
            print(e)


class EventsRange(Resource):
    def get(self, range):  # range в формате Y-m-d:Y-m-d
        try:
            dates = range.split(':')
            date_1 = datetime.datetime.strptime(dates[0], '%Y-%m-%d')
            date_2 = datetime.datetime.strptime(dates[1], '%Y-%m-%d')
            engine = sqlalchemy.create_engine(f"mysql+mysqlconnector://{USER}:{PASSWORD}@localhost/kcodbforbots",
                                              echo=False)
            responce = get('http://localhost:5000/api/key=***/events').json()
            events = []
            for event in responce['events']:
                date_finish = event['Edate_of_finish_event'].split('-')
                date_start = event['Edate_of_start_event'].split('-')
                if datetime.datetime(int(date_start[0]), int(date_start[1]), int(date_start[2])) >= date_1 \
                        and datetime.datetime(int(date_finish[0]), int(date_finish[1]), int(date_finish[2])) <= date_2:
                    events.append(event)
            return jsonify({'events': [item for item in events]})

        except Exception as e:
            print(e)




# return jsonify()

