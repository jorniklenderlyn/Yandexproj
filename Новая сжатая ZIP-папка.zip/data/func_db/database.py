import sqlalchemy
import sqlite3

import sys
sys.path.insert(1, r'C:\Users\npavlichenko\Desktop\DEV')

from data.func_db.db_session import global_init, create_session, create_db, delete_db
from data.models.VKusers import VKuser
from data.models.TLusers import TLuser
from data.models.tbidea import Idea
from data.models.events import Event


def add_TL_user(Utl_id, Uusername):
    global_init('kcodbforbots')
    db_sess = create_session()
    if not db_sess.query(TLuser).filter(TLuser.Uusername == Uusername).first():
        u = TLuser()
        u.Utl_id = Utl_id
        u.Uusername = Uusername
        db_sess.add(u)
        db_sess.commit()


def get_id_username():
    text = ''
    global_init('kcodbforbots')
    db_sess = create_session()
    for i in db_sess.query(TLuser).all():
        text += str(i.id) + '. ' + str(i.Utl_id) + ': ' + str(i.Uusername) + '\n'
    return text


def get_class_user(Utl_id):
    global_init('kcodbforbots')
    db_sess = create_session()
    if db_sess.query(TLuser).filter(TLuser.Utl_id == Utl_id).first():
        return db_sess.query(TLuser).filter(TLuser.Utl_id == Utl_id).first().Uclass
    return None


def change_user_what(Utl_id, hz, param):
    global_init('kcodbforbots')
    db_sess = create_session()
    u = db_sess.query(TLuser).filter(TLuser.Utl_id == Utl_id)
    if param == 'class':
        print('CLASS')
        u.update({TLuser.Uclass: hz}, synchronize_session = False)
    elif param == 'mailing-schedule':
        u.update({TLuser.Umailing_schedule: hz}, synchronize_session=False)
    elif param == 'mailing-events':
        u.update({TLuser.Umailing_events: hz}, synchronize_session=False)
    elif param == 'itcube-section':
        u.update({TLuser.Uitcube_section: hz}, synchronize_session=False)
    db_sess.commit()


def chek_user(Utl_id, param):
    global_init('kcodbforbots')
    db_sess = create_session()
    u = db_sess.query(TLuser).filter(TLuser.Utl_id == Utl_id).first()
    if param == 'class':
        if db_sess.query(TLuser).filter(TLuser.Utl_id == Utl_id).first():
            if u.Uclass:
                return True
    elif param == 'mailing-schedule':
        if u.Umailing_schedule:
            return True
    elif param == 'mailing-events':
        if u.Umailing_events:
            return True
    return False


def get_class_users(param):
    user_dict = dict()
    global_init('kcodbforbots')
    db_sess = create_session()
    for i in db_sess.query(TLuser).all():
        if param == 'mailing_schedule' and i.Umailing_schedule:
            Uid, Uclass = i.Utl_id, i.Uclass
            if Uclass not in user_dict:
                user_dict[Uclass] = [Uid]
            else:
                user_dict[Uclass] = user_dict[Uclass] + [Uid]
        if param == 'mailing_events' and i.Umailing_events:
            Uid, Uclass = i.Utl_id, i.Uclass
            if Uclass not in user_dict:
                user_dict[Uclass] = [Uid]
            else:
                user_dict[Uclass] = user_dict[Uclass] + [Uid]

    return user_dict


def get_events(param):
    global_init('kcodbforbots')
    db_sess = create_session()
    lst = []
    if param == 'all':
        for i in db_sess.query(Event).all():
            Eventdict = dict()
            Eventdict['@TITLE'] = i.Etitle_of_event
            Eventdict['@DATEOFBUBLICATION'] = str(i.date_of_publiction)
            Eventdict['@DATEOFSTART'] = str(i.Edate_of_start_event)
            Eventdict['@DATEOFFINISH'] = str(i.Edate_of_finish_event)
            Eventdict['@STATUSOFSPECIALITY'] = str(i.Estatus_of_speciality)
            Eventdict['@STATUSOFSCHOOL'] = str(i.Estatus_of_school)
            Eventdict['@STATUSOFCLASS'] = str(i.Estatus_of_class)
            Eventdict['@DESCRIPTION'] = str(i.Edescription)
            lst.append(Eventdict)
    if param == 'new':
        if db_sess.query(Event).first():
            for i in db_sess.query(Event).all():
                if i.TLnumber_of_mailing:
                    Eventdict = dict()
                    Eventdict['@TITLE'] = i.Etitle_of_event
                    Eventdict['@DATEOFBUBLICATION'] = str(i.date_of_publiction)
                    Eventdict['@DATEOFSTART'] = str(i.Edate_of_start_event)
                    Eventdict['@DATEOFFINISH'] = str(i.Edate_of_finish_event)
                    Eventdict['@STATUSOFSPECIALITY'] = str(i.Estatus_of_speciality)
                    Eventdict['@STATUSOFSCHOOL'] = str(i.Estatus_of_school)
                    Eventdict['@STATUSOFCLASS'] = str(i.Estatus_of_class)
                    Eventdict['@DESCRIPTION'] = str(i.Edescription)
                    e = db_sess.query(Event).filter(Event.id == i.id)
                    e.update({Event.TLnumber_of_mailing: i.TLnumber_of_mailing - 1}, synchronize_session=False)
                    db_sess.commit()
                    lst.append(Eventdict)
    return lst


def add_event(Eventdict, number_of_mailing=None):
    global_init('kcodbforbots')
    db_sess = create_session()
    e = Event()
    e.Etitle_of_event = Eventdict['@TITLE']
    e.Edate_of_start_event = Eventdict['@DATEOFSTART']
    e.Edate_of_finish_event = Eventdict['@DATEOFFINISH']
    e.Estatus_of_speciality = Eventdict['@STATUSOFSPECIALITY']
    e.Estatus_of_school = Eventdict['@STATUSOFSCHOOL']
    e.Estatus_of_class = Eventdict['@STATUSOFCLASS']
    e.Edescription = Eventdict['@DESCRIPTION']
    if TLnumber_of_mailing:
        e.TLnumber_of_mailing = number_of_mailing
    db_sess.add(e)
    db_sess.commit()




def get_day(id):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM days WHERE id = ?;", (id, )).fetchone()
    con.close()
    return result


def get_teacher(id):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM teachers WHERE id = ?;", (id, )).fetchone()
    con.close()
    return result


def get_schedule_itcube(id):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    if id == 'all':
        result = cur.execute("SELECT * FROM timetable;").fetchall()
    else:
        result = cur.execute("SELECT * FROM timetable WHERE name = ? ORDER BY day ASC;", (id, )).fetchall()
    con.close()
    return result


def get_section_name_itcube(id):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    if id == 'all':
        result = cur.execute("SELECT * FROM names;").fetchall()
    else:
        result = cur.execute("SELECT * FROM names WHERE id = ?;", (id, )).fetchone()
    con.close()
    return result


def add_idea(Iid, msger, Itext):
    global_init('kcodbforbots')
    db_sess = create_session()
    if not db_sess.query(Idea).filter(Idea.Itext == Itext).first():
        I = Idea()
        I.Iid = Iid
        I.Imsger = msger
        I.Itext =Itext
        db_sess.add(I)
        db_sess.commit()


def get_idea(param):
    global_init('kcodbforbots')
    db_sess = create_session()
    if param =='all':
        return [i.Itext for i in db_sess.query(Idea).all()]


if __name__ == '__main__':
    """
    Eventdict = dict()
    Eventdict['@TITLE'] = "e.Etitle_of_event"
    Eventdict['@DATEOFBUBLICATION'] = "str(e.date_of_publiction)"
    Eventdict['@DATEOFSTART'] = "str(e.Edate_of_start_event)"
    Eventdict['@DATEOFFINISH'] = "str(e.Edate_of_finish_event)"
    Eventdict['@STATUSOFSPECIALITY'] = "str(e.Estatus_of_speciality)"
    Eventdict['@STATUSOFSCHOOL'] = "str(e.Estatus_of_school)"
    Eventdict['@STATUSOFCLASS'] = "str(e.Estatus_of_class)"
    Eventdict['@DESCRIPTION'] = "str(e.Edescription)"
    add_event(Eventdict)
    """
    #print(get_events('new'))
    #get_events('new')
    print(get_class_users('VKmailing_schedule'))

    pass
