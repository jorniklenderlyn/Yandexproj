import vk_api

import sys
sys.path.insert(1, r'C:\Users\npavlichenko\Desktop\DEV')

import json
from vk_api import VkUpload
from vk_api.longpoll import VkLongPoll, VkEventType
from vk_api.utils import get_random_id
import vk_api.keyboard
import datetime
import fitz
import os
import requests
import sqlalchemy
import sqlite3
from data.func_db.db_session import global_init, create_session, create_db, delete_db
from data.models.VKusers import VKuser
from data.models.events import Event
from PIL import Image
from threading import Thread
from data.models.VKusers import VKuser
from data.func_db.db_session import global_init, create_session
from data.schedule.schedule import Schedule
boxOfImages = []
update_hours_list = [16, 8, 19, 9]
url_today = ''
url_to_download = ''
list_with_checklists = []
downloading_checklist_now = False
global_init('kcodbforbots')
downloaded = list()


def add_VK_user(Uvk_id):
    global_init('kcodbforbots')
    db_sess = create_session()
    # print(db_sess.query(VKuser).all())
    if not db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id).first():
        u = VKuser()
        u.Uvk_id = Uvk_id
        db_sess.add(u)
        db_sess.commit()


def get_vk_class_user(Uvk_id):
    global_init('kcodbforbots')
    db_sess = create_session()
    if db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id).first():
        print('cocicka')
        for i in db_sess.query(VKuser).all():
            print(i.Uclass)
        return db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id).first().Uclass
    return None


def change_user_what(Uvk_id, hz, param):
    global_init('kcodbforbots')
    db_sess = create_session()

    u = db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id)
    if param == 'class':

        u.update({VKuser.Uclass: hz}, synchronize_session=False)
    elif param == 'mailing-schedule':
        u.update({VKuser.Umailing_schedule: hz}, synchronize_session=False)
    elif param == 'mailing-events':
        u.update({VKuser.Umailing_events: hz}, synchronize_session=False)
    elif param == 'itcube-section':
        u.update({VKuser.Uitcube_section: hz}, synchronize_session=False)
    db_sess.commit()
    


def chek_vk_user(Uvk_id, param):
    db_sess = create_session()
    u = db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id).first()
    if param == 'class':
        if db_sess.query(VKuser).filter(VKuser.Uvk_id == Uvk_id).first():
            # print(u.Uclass)
            if u.Uclass:
                return True
    elif param == 'mailing-schedule':
        if u.Umailing_schedule:
            return True
    elif param == 'mailing-events':
        if u.Umailing_events:
            return True
    return False


def get_vk_all_class_users():
    user_dict = dict()
    db_sess = create_session()
    for i in db_sess.query(VKuser).all():
        Uid, Uclass = i.Uvk_id, i.Uclass
        if Uclass not in user_dict:
            user_dict[Uclass] = [Uid]
        else:
            user_dict[Uclass] = user_dict[Uclass] + [Uid]
    return user_dict


def get_events(param):
    db_sess = create_session()
    lst = []
    if param == 'all':
        for i in db_sess.query(Event).all():
            Eventdict = dict()
            Eventdict['@TITLE'] = i.Etitle_of_event
            Eventdict['@DATEOFBUBLICATION'] = str(i.date_of_publiction)
            Eventdict['@DATEOFSTART'] = str(i.Edate_of_start_event)
            Eventdict['@DATEOFFINISH'] = str(i.Edate_of_finish_event)
            Eventdict['@STATUSOFSPECIALITY'] = str(i.Estatus_of_speciality)
            Eventdict['@STATUSOFSCHOOL'] = str(i.Estatus_of_school)
            Eventdict['@STATUSOFCLASS'] = str(i.Estatus_of_class)
            Eventdict['@DESCRIPTION'] = str(i.Edescription)
            lst.append(Eventdict)
    return lst


def get_day(uid):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM days WHERE id = ?;", (uid, )).fetchone()
    con.close()
    return result


def get_teacher(uid):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM teachers WHERE id = ?;", (uid, )).fetchone()
    con.close()
    return result


def get_schedule_itcube(uid):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    if uid == 'all':
        result = cur.execute("SELECT * FROM timetable;").fetchall()
    else:
        result = cur.execute("SELECT * FROM timetable WHERE name = ? ORDER BY day ASC;", (uid, )).fetchall()
    con.close()
    return result


def get_section_name_itcube(uid):
    con = sqlite3.connect("db/db.db")
    cur = con.cursor()
    if uid == 'all':
        result = cur.execute("SELECT * FROM names;").fetchall()
    else:
        result = cur.execute("SELECT * FROM names WHERE id = ?;", (uid, )).fetchone()
    con.close()
    return result


class_list = {'5': ['1', '2', '3'],
              '6': ['1', '2', '3', '4', '5'],
              '7': ['1', '2', '3', '4', '5', '6.1', '6.2', '7.1', '7.2'],
              '8': ['1', '2', '3.1', '3.2'],
              '9': ['1', '2', '3', '4.1', '4.2', '5'],
              '10': ['1 ен', '1 т', '2 гум', '2 сэ'],
              '11': ['1', '2 гум', '2 ен', '2 сэ'],
              }
vk_session = vk_api.VkApi(token='30b12320d099fcf622461de8875d3526b105e8e70863a79d290e90e075d5cde48c582aa6261fdab0ab8a0')
vk = vk_session.get_api()
longpol = VkLongPoll(vk_session)
Flag_msg = False
userclass = {}


def get_button(text, color):
    return {
        "action": {
            "type": "text",
            "payload": "{\"button\": \"" + "3" + "\"}",
            "label": f"{text}"
        },
        "color": f"{color}"
    }


def get_keyboard(buttonslist, one_time_flag=True):
    keyboard = {
        "one_time": one_time_flag,
        "buttons": [
            buttonslist
        ]
    }
    keyboard = json.dumps(keyboard, ensure_ascii=False).encode('utf-8')
    keyboard = str(keyboard.decode('utf-8'))
    return keyboard


def get_big_keyboard(buttonlist):
    keyboard = vk_api.keyboard.VkKeyboard(one_time=True)
    len_buttons_list = len(buttonlist)
    if len_buttons_list % 3 == 0:
        flag = 0
        for buttongroupind in range(len_buttons_list):
            if flag != 0 and flag % 3 == 0:
                keyboard.add_line()
            keyboard.add_button(buttonlist[buttongroupind]['action']['label'],
                                color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
            flag += 1
    if len_buttons_list == 4:
        keyboard.add_button(buttonlist[0]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[1]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[2]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[3]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
    if len_buttons_list == 5:
        keyboard.add_button(buttonlist[0]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[1]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[2]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[3]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[4]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
    if len_buttons_list == 7:
        keyboard.add_button(buttonlist[0]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[1]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[2]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[3]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[4]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[5]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[6]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
    if len_buttons_list == 8:
        keyboard.add_button(buttonlist[0]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[1]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[2]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[3]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[4]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[5]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_line()
        keyboard.add_button(buttonlist[6]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)
        keyboard.add_button(buttonlist[7]['action']['label'],
                            color=vk_api.keyboard.VkKeyboardColor.PRIMARY)        
    return keyboard.get_keyboard()


def messegeoperator(userid, text, keyboardflag=False, buttons=None, sizekeyboard=False):
    # print('<--------->', get_keyboard(buttons), '<----------->')
    if keyboardflag:
        if sizekeyboard:
            vk_session.method('messages.send',
                              {'user_id': userid, 'message': text, 'random_id': 0,
                               'keyboard': get_big_keyboard(buttons)})
        else:
            vk_session.method('messages.send',
                              {'user_id': userid, 'message': text, 'random_id': 0,
                               'keyboard': get_keyboard(buttons)})
    else:
        vk_session.method('messages.send',
                          {'user_id': userid, 'message': text, 'random_id': 0})


def upload_photo(upload, photo):
    response = upload.photo_messages(photo)[0]
    owner_id = response['owner_id']
    photo_id = response['id']
    access_key = response['access_key']
    # print(owner_id, photo_id, access_key)
    return owner_id, photo_id, access_key


def send_photo(peer_id, owner_id, photo_id, access_key):
    attachment = f'photo{owner_id}_{photo_id}_{access_key}'
    vk.messages.send(
        random_id=get_random_id(),
        peer_id=peer_id,
        attachment=attachment
    )


def digitinstr(string):
    for char in string:
        if char.isdigit():
            return True
    return False


def newuser(usid):
    global userclass
    if usid in userclass:
        pass
    else:
        'table'.encode('utf-8')
        userclass[usid] = {}
        userclass[usid]['table'] = None
        userclass[usid]['grouplist'] = None
        userclass[usid]['firstdate'] = True
        userclass[usid]['classflag'] = False
        userclass[usid]['checklistflagkco'] = True
        userclass[usid]['eventlistflagkco'] = True
        userclass[usid]['sectflag'] = False


def get_group(classname):
    for char in classname:
        if char == ".":
            return classname[classname.index(char):]


def give_me_checklist(usid, idsc):
    for sc in get_schedule_itcube(idsc):
        messege = f'{get_day(sc[2])[1]}' \
                  f' \n Время начала:{sc[3]}' \
                  f' \n Кабинет: {sc[4]}' \
                  f' \n Учитель: {get_teacher(sc[5])[1]}'
        messegeoperator(usid, messege)


def main():
    global Flag_msg, userclass, class_list
    listcommand = ['начать', 'кцо', 'it_cube', '📅расписание',
                   '🔧настройки', 'сменить класс', 'назад',
                   'расписания✅', 'события✅',
                   'расписания⛔', 'события⛔',
                   '📋направления', 'К организациям',
                   'назад.']
    list_of_section = [get_button(section[-1], 'primary')
                       for section in get_section_name_itcube('all')]
    lof = [str(sc[1]).lower() for sc in get_section_name_itcube('all')]
    # print(lof)
    for event in longpol.listen():
        try:
            if event.type == VkEventType.MESSAGE_NEW:
                if event.to_me:
                    userid = event.user_id
                    msg = event.text.lower()
                    newuser(userid)
                    add_VK_user(userid)
                    print(userid, msg, datetime.datetime.today())
                    try:
                        if userclass[userid]['sectflag']:
                            if msg in lof:
                                give_me_checklist(userid, lof.index(msg) + 1)
                                messegeoperator(userid, 'Что вы хотите?', keyboardflag=True,
                                                buttons=[get_button('📋Направления', 'primary'),
                                                         get_button('Назад.', 'primary')])
                                userclass[userid]['sectflag'] = False
                            else:
                                messegeoperator(userid, "Повторите запрос!")
                        elif msg in listcommand:
                            idcommand = listcommand.index(msg)
                            if (idcommand == 0 or idcommand == 13 or idcommand == 14) and chek_vk_user(userid, 'class')\
                                    and not userclass[userid]['firstdate']:
                                messegeoperator(userid, "Что вы хотите?", keyboardflag=True,
                                                buttons=[get_button('📅Расписание', 'primary'),
                                                         get_button('🔧Настройки', 'primary'),
                                                         get_button('IT_cube', 'primary')],
                                                sizekeyboard=True)
                            elif idcommand == 0 or idcommand == 5 or idcommand == 12 or idcommand == 13 or idcommand == 6\
                                    and userclass[userid]['firstdate']:
                                userclass[userid]['firstdate'] = False
                                add_VK_user(userid)
                                messegeoperator(userid, "Привет! Ты в какую организацию?", keyboardflag=True,
                                                buttons=[get_button('КЦО', 'primary'),
                                                         get_button('IT_cube', 'positive')])
                            if idcommand == 1:
                                messegeoperator(userid, 'В каком вы классе?', keyboardflag=True,
                                                buttons=[get_button('5', 'primary'),
                                                         get_button('6', 'primary'),
                                                         get_button('7', 'primary'),
                                                         get_button('8', 'primary'),
                                                         get_button('9', 'primary'),
                                                         get_button('10', 'primary'),
                                                         get_button('11', 'primary'),
                                                         get_button('Назад', 'primary')], sizekeyboard=True)
                            if idcommand == 3:
                                try:
                                    upload = VkUpload(vk)
                                    url = str(get_vk_class_user(userid))
                                    print(url)
                                    send_photo(userid, *upload_photo(upload, f'data/data/{url.upper()}.jpg'))
                                    messegeoperator(userid, 'Что вы хотите?',
                                                    keyboardflag=True, buttons=[get_button('📅Расписание', 'primary'),
                                                                                get_button('🔧Настройки', 'primary'),
                                                                                get_button('IT_cube', 'primary')],
                                                    sizekeyboard=True)
                                except ValueError as error:
                                    print(str(error))
                                    messegeoperator(userid, "--Возникла ошибка!--\n"
                                                            "--Возможно вас нет в базе данных--\n"
                                                            "--Нажмите или напишите 'НАЧАТЬ'",
                                                    keyboardflag=True,
                                                    buttons=[get_button('Начать', 'primary')])
                                    messegeoperator(510166680, f'У {userid} возникла проблема с бд')
                            if idcommand == 4:
                                messegeoperator(userid, 'Что вы хотите?',
                                                keyboardflag=True, buttons=[get_button('Сменить класс', 'primary'),
                                                                            get_button('Расписания✅'
                                                                                       if userclass[userid]['checklistflagkco']
                                                                                       else 'Расписания⛔', 'primary'),
                                                                            get_button('События✅'
                                                                                       if userclass[userid]['eventlistflagkco']
                                                                                       else 'События⛔', 'primary'),
                                                                            get_button('Назад', 'primary')],
                                                sizekeyboard=True)
                                userclass[userid]['classflag'] = False
                            if idcommand == 6:
                                messegeoperator(userid, 'Что вы хотите?',
                                                keyboardflag=True, buttons=[get_button('📅Расписание', 'primary'),
                                                                            get_button('🔧Настройки', 'primary'),
                                                                            get_button('IT_cube', 'primary')],
                                                sizekeyboard=True)
                            if idcommand in range(7, 11):
                                if idcommand == 7:
                                    userclass[userid]['checklistflagkco'] = False
                                    change_user_what(userid, True, 'mailing-schedule')
                                if idcommand == 8:
                                    userclass[userid]['eventlistflagkco'] = False
                                    change_user_what(userid, True, 'mailing-events')
                                if idcommand == 9:
                                    userclass[userid]['checklistflagkco'] = True
                                    change_user_what(userid, False, 'mailing-schedule')
                                if idcommand == 10:
                                    userclass[userid]['eventlistflagkco'] = True
                                    change_user_what(userid, False, 'mailing-events')
                                messegeoperator(userid, 'Что вы хотите?',
                                                keyboardflag=True, buttons=[get_button('Сменить класс', 'primary'),
                                                                            get_button('Расписания✅'
                                                                                       if userclass[userid]['checklistflagkco']
                                                                                       else 'Расписания⛔', 'primary'),
                                                                            get_button('События✅'
                                                                                       if userclass[userid]['eventlistflagkco']
                                                                                       else 'События⛔', 'primary'),
                                                                            get_button('Назад', 'primary')],
                                                sizekeyboard=True)
                            if idcommand == 2:
                                if not userclass[userid]['firstdate']:
                                    messegeoperator(userid, "Добро пожаловать в IT_cube!",
                                                    keyboardflag=True, buttons=[get_button('📋Направления', 'primary'),
                                                                                get_button('Назад.', 'primary')])
                                else:
                                    messegeoperator(userid, "Добро пожаловать в IT_cube!",
                                                    keyboardflag=True, buttons=[get_button('📋Направления', 'primary'),
                                                                                get_button('Назад', 'primary')])
                            if idcommand == 11:
                                messegeoperator(userid, "Вы куда?", keyboardflag=True,
                                                buttons=list_of_section, sizekeyboard=True)
                                userclass[userid]['sectflag'] = True
                        elif digitinstr(msg):
                            if not userclass[userid]['classflag']:
                                if int(msg) in range(5, 12):
                                    userclass[userid]['table'] = msg
                                    userclass[userid]['grouplist'] = []
                                    buttonsgroup = []
                                    for group in class_list[msg]:
                                        userclass[userid]['grouplist'].append(group)
                                        buttonsgroup.append(get_button(userclass[userid]['table'] + "." + group, 'primary'))
                                    messegeoperator(userid, 'В какой ты группе?', keyboardflag=True,
                                                    buttons=buttonsgroup, sizekeyboard=True)
                                    userclass[userid]['classflag'] = True
                                    continue
                            else:
                                userclass[userid]['table'] += get_group(msg)
                                print(userclass[userid])
                                userclass[userid]['classflag'] = False
                                userclass[userid]['grouplist'] = []
                                upload = VkUpload(vk)
                                url = userclass[userid]['table']
                                send_photo(userid, *upload_photo(upload, f'data/data/{url.upper()}.jpg'))
                                print(userclass[userid]['table'])
                                change_user_what(userid, userclass[userid]['table'], 'class')
                                messegeoperator(userid, 'Ваши данные обновлены')
                                # print(userclass)
                                messegeoperator(userid, 'Что вы хотите?',
                                                keyboardflag=True, buttons=[get_button('📅Расписание', 'primary'),
                                                                            get_button('🔧Настройки', 'primary'),
                                                                            get_button('IT_cube', 'primary')],
                                                sizekeyboard=True)
                        else:
                            messegeoperator(userid, '--Error--\n'
                                                    '--Возникла ошибка!--\n'
                                                    '--Повторите запрос или обратитесь в техническую поддержку!--\n'
                                                    '--Попробуйте отчистить историю или написать "Начать"--',
                                            keyboardflag=True, buttons=[get_button("Начать", 'primary')])
                            messegeoperator(510166680, f'{userid} ввёл неправильную команду!')
                    except ValueError as error:
                        messegeoperator(510166680, f'У {userid} произошла ошибка!')
        except ValueError as error:
            messegeoperator(510166680, 'Произошла ошибка! Надо идти исправлять!')


def automatic_notification():
    users_list = get_vk_all_class_users()
    for item in users_list.items():
        upload = VkUpload(vk)
        user_class = item[0]
        for user_name in users_list[user_class]:
            try:
                if chek_vk_user(int(user_name), 'mailing-schedule'):
                    messegeoperator(int(user_name), 'Авторассылка')
                    send_photo(int(user_name), *upload_photo(upload, f'data/data/{str(user_class).upper()}.jpg'))
            except ValueError as error:
                messegeoperator(510166680, 'Кто-то замутил бота!')


def vk_bot_work():
    while True:
        main()


def updater_work():
    while True:
        datan = str(datetime.datetime.now().time()).split('.')[0]
        datatimelist = ['16:10:05', '18:00:05', '20:00:05', '6:30:05', '18:06:30']
        if datan in datatimelist:
            sch = Schedule('C:\\Users\\npavlichenko\\Desktop\\DEV\\data\\schedule', 'q.pdf')
            sch.download_pdf()
            sch.make_lessonslists(sch.get_classes())
            if sch.download_pdf():
                automatic_notification()


messegeoperator(510166680, 'Начало работы бота')
sch = Schedule('C:\\Users\\npavlichenko\\Desktop\\DEV\\data\\schedule', 'q.pdf')
sch.download_pdf()
sch.make_lessonslists(sch.get_classes())
thread1 = Thread(target=vk_bot_work)
thread2 = Thread(target=updater_work)
thread1.start()
thread2.start()
thread1.join()
thread2.join()
