import json
import os
import datetime
import logging
from os import abort

from flask import Flask, render_template, request
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_restful import Api
from werkzeug.utils import redirect

import sys
sys.path.insert(1, r'C:\Users\npavlichenko\Desktop\DEV')

from data.func_db import db_session, events_resources
from data.models.admins import Admin
from data.models.events import Event
from data.models.VKusers import VKuser
from data.models.TLusers import TLuser
from forms.admin import RegisterForm, LoginForm
from forms.event import EventForm

from requests import get
from alice.alice_const import *
from alice.alice_database import get_day, get_teacher, get_schedule_itcube

app = Flask(__name__)
api = Api(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)

sessionStorage = {}

logging.basicConfig(filename=r"C:\Users\npavlichenko\Desktop\DEV\xampp\htdocs\web\log.log")


class EventApi:
    def __init__(self, apikey):
        self.apikey = apikey

    def request(self, k: str = ''):
        try:
            result = get(f'http://localhost:80/api/key={self.apikey}/events/' + k).json()
            if type(result) == str and 'not found' in result:
                return 0
            return result
        except Exception as e:
            logging.warning(e)
            return 0

    def id_request(self, n: int):
        return self.request(str(n))

    def get_all(self):
        return self.request()

    def date_request(self, d1: datetime, d2: datetime):
        m = d1.strftime('%Y/%m/%d')
        m += ':'
        m += d2.strftime('%Y/%m/%d')
        return self.request(m)


alice_api = EventApi('***')


@app.route("/")
def index():
    return render_template("index.html", title='Чат-бот ВК')


# ВХОД

@login_manager.user_loader
def load_user(user_id):
    db_session.global_init("kcodbforbots")
    db_sess = db_session.create_session()
    return db_sess.query(Admin).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    db_session.global_init("kcodbforbots")
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        admin = db_sess.query(Admin).filter(Admin.Alogin == form.Alogin.data).first()
        if admin and admin.check_password(form.Apassword.data):
            login_user(admin, remember=form.remember_me.data)
            return redirect("/menu")
        return render_template('login.html',
                               message="Пользователя с таким логином не существует",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")

#


# МЕНЮ

@app.route("/menu")
def menu():
    return render_template("menu.html", title="Главное меню")

#


# АДМИНЫ

@app.route("/admins")
def admins():
    db_session.global_init("kcodbforbots")
    db_sess = db_session.create_session()
    admins = db_sess.query(Admin).all()
    return render_template("admins.html", title="Администраторы", admins=admins, count=len(admins))


@app.route('/admins/register', methods=['GET', 'POST'])
def reqister():
    db_session.global_init("kcodbforbots")
    form = RegisterForm()
    if form.validate_on_submit():
        if form.Apassword.data != form.Apassword_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(Admin).filter(Admin.Alogin == form.Alogin.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")

        admin = Admin(
            Aname=form.Aname.data,
            Astatus=form.Astatus.data,
            Alogin=form.Alogin.data,
        )
        admin.set_password(form.Apassword.data)
        db_sess.add(admin)
        db_sess.commit()
        return redirect('/admins')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/admins/delete_admin/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_admin(id):
    db_session.global_init("kcodbforbots")
    db_sess = db_session.create_session()
    admin = db_sess.query(Admin).filter(Admin.id == id, current_user.Astatus == 2).first()
    if admin:
        db_sess.delete(admin)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/admins')

#


# СОБЫТИЯ

@app.route("/events")
def events():
    db_session.global_init("kcodbforbots")
    db_sess = db_session.create_session()
    events = db_sess.query(Event).all()
    return render_template("events.html", title="События", events=events, count=len(events))


@app.route('/events/add_event',  methods=['GET', 'POST'])
@login_required
def add_event():
    db_session.global_init("kcodbforbots")
    status_school = {'1': 'Школа', '2': 'IT-куб'}
    status_speciality = {'1': {'0': "физ-мат", '1': "соц-гум", '2': "соц-эконом", '3': "хим-био", '4': "спорт"},
                         '2': {'0': "Яндекс Лицей", '1': "Samsung", '2': "Английский язык", '3': "C++"}}
    form = EventForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        event = Event(
            Etitle_of_event=form.Etitle_of_event.data,
            Edate_of_start_event=form.Edate_of_start_event.data,
            Edate_of_finish_event=form.Edate_of_finish_event.data,
            Estatus_of_class=form.Estatus_of_class.data,
            Estatus_of_school=status_school[request.form.get('select_speciality')],
            Estatus_of_speciality=status_speciality[request.form.get('select_speciality')][request.form.get('resort[]')],
            VKnumber_of_mailing=form.VKnumber_of_mailing.data,
            TLnumber_of_mailing=form.TLnumber_of_mailing.data,
            Edescription=form.Edescription.data,
            Ephoto=form.Ephoto.data
        )
        db_sess.add(event)
        db_sess.commit()
        if event.Ephoto != None:
            photo = True
            path = f"static/img/{event.Ephoto}"
            if os.path.isfile(path):
                data = open(path, "rb").read()
                f = open(f"static/img/{event.id}.jpg", "wb")
                f.write(data)
                os.remove(path)
        return redirect('/events')
    return render_template('event.html', title='Добавление события', form=form)


@app.route('/events/delete_event/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_event(id):
    db_session.global_init("kcodbforbots")
    db_sess = db_session.create_session()
    event = db_sess.query(Event).filter(Event.id == id).first()
    if event:
        if os.path.isfile(f'static/img/{id}.jpg'):
            os.remove(f'static/img/{id}.jpg')
        db_sess.delete(event)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/events')

#


# ПОЛЬЗОВАТЕЛИ

@app.route("/users")
def users():
    if request.method == 'GET':
        db_session.global_init("kcodbforbots")
        db_sess = db_session.create_session()
        VKusers = db_sess.query(VKuser).all()
        TLusers = db_sess.query(TLuser).all()
        len_users = len(VKusers) + len(TLusers)
        with open(r'C:\Users\npavlichenko\Desktop\DEV\xampp\htdocs\web\data/count_users.json', 'w', encoding='utf-8') as file:
            users_dict = {
                'users': "1",
                'VKusers': len(VKusers),
                'TLusers': len(TLusers)
            }
            json.dump(users_dict, file)
            done_js_file = [list([i, j]) for i, j in users_dict.items()]
        return render_template("users.html", title="Пользователи", count=len_users, js=done_js_file)

#
@app.route("/info")
def info():
        return render_template("info.html", title="Информация")


#**********************************************
@app.route('/alice', methods=['POST'])
def alice_response():
    logging.info(f'Request: {request.json!r}')

    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }

    handle_dialog(request.json, response)

    logging.info(f'Response:  {response!r}')

    return json.dumps(response)


def handle_dialog(req, res):
    user_id = req['session']['user_id']
    text = req["request"]['original_utterance'].lower()

    if req['session']['new']:

        sessionStorage[user_id] = {
            'suggests': [
                "Расписание",
                "Информация о направлениях",
                "События"
            ],
            'step': START,
            'direction': None
        }
        res['response']['text'] = 'Привет! Я могу рассказать тебе расписание или информацию о направлениях ItCube'
        res['response']['buttons'] = get_suggests(user_id)
        return
    if sessionStorage[user_id]['step'] == START:
        if 'расписан' in text:
            sessionStorage[user_id] = {
                'suggests': [str(x) for x in range(1, 17)],
                'step': SCHEDULE,
                'direction': None
            }
            res['response']['text'] = '1. Программирование на Python, Яндекс.Лицей.\n' \
                                      '2. IT школа SAMSUNG.\n' \
                                      '3. VR/AR - разработка.\n' \
                                      '4. Кибергигиена и большие данные.\n' \
                                      '5. Основы алгоритмики и логики.\n' \
                                      '6. Робототехника.\n' \
                                      '7. Системное администрирование.\n' \
                                      '8. Основы искуственного интелекта.\n' \
                                      '9. Основы программирования и цифровой грамотности.\n' \
                                      '10. Медиатехнологии.\n' \
                                      '11. Программиравание Си-подобные.\n' \
                                      '12. Нанодети.\n' \
                                      '13. Математика.\n' \
                                      '14. Английский язык.\n' \
                                      '15. Проектная школа.\n' \
                                      '16. Биодети.\n' \
                                      'Выбери направление:'
            res['response']['buttons'] = get_suggests(user_id)
        elif ('описан' in text or 'информ' in text) and 'направл' in text:
            sessionStorage[user_id] = {
                'suggests': [str(x) for x in range(1, 10)],
                'step': INFORMATION,
                'direction': None
            }
            res['response']['text'] = '1. Яндекс.Лицей.\n' \
                                      '2. IT школа SAMSUNG.\n' \
                                      '3. VR/AR - разработка.\n' \
                                      '4. Кибергигиена и большие данные.\n' \
                                      '5. Основы алгоритмики и логики.\n' \
                                      '6. Робототехника.\n' \
                                      '7. Системное администрирование.\n' \
                                      '8. Основы искуственного интелекта.\n' \
                                      '9. Основы программирования и цифровой грамотности.\n' \
                                      'Выбери направление:'
            res['response']['buttons'] = get_suggests(user_id)
        elif 'событ' in text:
            res['response']['text'] = 'Привет, Крокозябра!\nТы хочешь узнать события куба за эту неделю или следующую?'
            sessionStorage[user_id]['step'] = EVENTS
            sessionStorage[user_id]['suggests'] = [
                'Эта неделя',
                'Следующая неделя'
            ]
            res['response']['buttons'] = get_suggests(user_id)
        else:
            res['response']['text'] = 'Я не расслышала, повтори, пожалуйста.'
            res['response']['buttons'] = get_suggests(user_id)
    elif sessionStorage[user_id]['step'] == SCHEDULE:
        num = get_number(req)
        if num and 0 < num < 17:
            sessionStorage[user_id] = {
                'suggests': [
                    "Вернуться"
                ],
                'step': ANSWERED_ALL,
                'direction': None
            }
            text_all = []
            for num_num in DATABASE_TO_CODE[num]:
                for i in get_schedule_itcube(num_num):
                    text = ''
                    text += get_day(i[2])[1] + '\n'
                    text += 'Время начала: ' + str(i[3]) + '\n'
                    text += 'Кабинет: ' + str(i[4]) + '\n'
                    text += 'Учитель: ' + get_teacher(i[5])[1] + '\n'
                    text_all.append((i[2], text))
            text_all.sort()
            text_all = [f'{x + 1}. ' + text_all[x][1] for x in range(len(text_all))]
            res['response']['text'] = '\n'.join(text_all)
            res['response']['buttons'] = get_suggests(user_id)
        else:
            res['response']['text'] = 'Я не расслышала, повтори, пожалуйста.'
            res['response']['buttons'] = get_suggests(user_id)
    elif sessionStorage[user_id]['step'] == INFORMATION:
        num = get_number(req)
        if num and 0 < num < 10:
            sessionStorage[user_id] = {
                'suggests': [
                    "Рекомедуемый возраст",
                    "Вернуться"
                ],
                'step': ANSWERED_INFORMATION,
                'direction': num
            }
            res['response']['text'] = DIRECTION_INFORMATION_TEXT[num]
            res['response']['buttons'] = get_suggests(user_id)
        else:
            res['response']['text'] = 'Я не расслышала, повтори, пожалуйста.'
            res['response']['buttons'] = get_suggests(user_id)
    elif sessionStorage[user_id]['step'] == ANSWERED_INFORMATION:
        if 'возраст' in text or 'лет' in text:
            if sessionStorage[user_id]['direction']:
                res['response']['text'] = DIRECTION_INFORMATION_AGE[sessionStorage[user_id]['direction']]
            else:
                res['response']['text'] = 'У меня ошибка!'
            sessionStorage[user_id] = {
                'suggests': [
                    "Рекомедуемый возраст",
                    "Вернуться"
                ],
                'step': ANSWERED_INFORMATION,
                'direction': sessionStorage[user_id]['direction']
            }
            res['response']['buttons'] = get_suggests(user_id)
        else:
            sessionStorage[user_id] = {
                'suggests': [
                    "Расписание",
                    "Информация о направлениях",
                    "События"
                ],
                'step': START,
                'direction': None
            }
            res['response']['text'] = 'Что ещё вы хотите узнать?'
            res['response']['buttons'] = get_suggests(user_id)
    elif sessionStorage[user_id]['step'] == ANSWERED_ALL:
        sessionStorage[user_id] = {
            'suggests': [
                "Расписание",
                "Информация о направлениях",
                "События"
            ],
            'step': START,
            'direction': None
        }
        res['response']['text'] = 'Что ещё вы хотите узнать?'
        res['response']['buttons'] = get_suggests(user_id)
    elif sessionStorage[user_id]['step'] == EVENTS:
        if 'эт' in text:
            dt = datetime.datetime.today()
            d1 = dt - datetime.timedelta(days=dt.weekday())
            d2 = d1 + datetime.timedelta(days=7)
            response = alice_api.date_request(d1, d2)
            if response == 0:
                res['response']['text'] = 'На этой неделе в кубе нет никаких событий'
            else:
                text123 = 'На этой неделе в кубе проходят следующие события:\n'
                for i in response['events']:
                    k1 = f'Событие {i["Etitle_of_event"]}\n'
                    k1 += f'Начало: {i["Edate_of_start_event"]}\n'
                    k1 += f'Конец: {i["Edate_of_finish_event"]}\n'
                    k1 += i['Edescription'] + '\n'
                    text123 += k1
                res['response']['text'] = text123
            sessionStorage[user_id]['suggests'] = [
                'Вернуться'
            ]
            sessionStorage[user_id]['step'] = ANSWERED_ALL
            res['response']['buttons'] = get_suggests(user_id)
        elif 'след' in text:
            dt = datetime.datetime.today()
            d1 = dt - datetime.timedelta(days=dt.weekday())
            d1 += datetime.timedelta(days=7)
            d2 = d1 + datetime.timedelta(days=7)
            response = alice_api.date_request(d1, d2)
            if response == 0:
                res['response']['text'] = 'На следующей неделе в кубе нет никаких событий'
            else:
                text123 = 'На следующей неделе в кубе проходят следующие события:\n'
                for i in response['events']:
                    k1 = f'Событие {i["Etitle_of_event"]}\n'
                    k1 += f'Начало: {i["Edate_of_start_event"]}\n'
                    k1 += f'Конец: {i["Edate_of_finish_event"]}\n'
                    k1 += i['Edescription'] + '\n'
                    text123 += k1
                res['response']['text'] = text123
            sessionStorage[user_id]['suggests'] = [
                'Вернуться'
            ]
            sessionStorage[user_id]['step'] = ANSWERED_ALL
            res['response']['buttons'] = get_suggests(user_id)
        else:
            res['response']['text'] = 'Я не расслышала, повтори, пожалуйста.'
            res['response']['buttons'] = get_suggests(user_id)

def get_suggests(user_id):
    session = sessionStorage[user_id]

    suggests = [
        {'title': suggest, 'hide': True}
        for suggest in session['suggests']
    ]

    return suggests


def get_number(req):
    for i in req["request"]['command'].split():
        if i.isdigit():
            return int(i)
    if req['request']['nlu']['intents']["direction"]["slots"]["piece"]["type"] == "ItCube":
        return int(req['request']['nlu']['intents']["direction"]["slots"]["piece"]["value"])


#**********************************************


def main():
    db_session.global_init("kcodbforbots")
    api.add_resource(events_resources.EventsListResource, '/api/events')
    api.add_resource(events_resources.EventResource, '/api/<string:key>/events/<int:event_id>')
    api.add_resource(events_resources.EventsRange, '/api/<string:key>/events/<string:range>')
    app.run(port=8090, host='127.0.0.1')


if __name__ == '__main__':
    if 0:
        db_session.global_init("kcodbforbots")
        db_sess = db_session.create_session()
        admin = Admin(
            Aname='AHOHuMNblu PE6OHOK',
            Astatus=2,
            Alogin='q',
        )
        admin.set_password('q')
        db_sess.add(admin)
        db_sess.commit()
    main()

