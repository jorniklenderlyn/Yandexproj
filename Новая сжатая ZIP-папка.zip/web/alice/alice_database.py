import sqlite3


def get_day(id):
    con = sqlite3.connect(r"C:\Users\npavlichenko\Desktop\DEV\xampp\htdocs\web\alice\timetable.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM days WHERE id = ?;", (id, )).fetchone()
    con.close()
    return result


def get_teacher(id):
    con = sqlite3.connect(r"C:\Users\npavlichenko\Desktop\DEV\xampp\htdocs\web\alice\timetable.db")
    cur = con.cursor()
    result = cur.execute("SELECT * FROM teachers WHERE id = ?;", (id, )).fetchone()
    con.close()
    return result


def get_schedule_itcube(id):
    con = sqlite3.connect(r"C:\Users\npavlichenko\Desktop\DEV\xampp\htdocs\web\alice\timetable.db")
    cur = con.cursor()
    if id == 'all':
        result = cur.execute("SELECT * FROM timetable;").fetchall()
    else:
        result = cur.execute("SELECT * FROM timetable WHERE name = ? ORDER BY day ASC;", (id, )).fetchall()
    con.close()
    return result
