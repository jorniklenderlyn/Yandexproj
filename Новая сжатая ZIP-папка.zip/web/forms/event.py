from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import SubmitField, DateField, FileField, SelectField
from wtforms.validators import DataRequired


class EventForm(FlaskForm):
    Etitle_of_event = StringField('Название', validators=[DataRequired()])
    Edate_of_start_event = DateField('Дата начала', format='%Y-%m-%d')
    Edate_of_finish_event = DateField('Дата завершения', format='%Y-%m-%d')
    Estatus_of_school = StringField('Школа / IT-куб')
    Estatus_of_speciality = StringField('Профиль / Секция')
    Estatus_of_class = SelectField('Класс', choices=[5, 6, 7, 8, 9, 10, 11], validators=[DataRequired()])
    Ephoto = FileField('Фото')
    VKnumber_of_mailing = StringField('Кол-во отправлений бота во ВКонтакте', validators=[DataRequired()])
    TLnumber_of_mailing = StringField('Кол-во отправлений бота в Телеграмме', validators=[DataRequired()])
    Edescription = TextAreaField('Описание события', validators=[DataRequired()])
    submit = SubmitField('Добавить')
