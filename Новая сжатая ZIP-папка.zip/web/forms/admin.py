from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, SubmitField, BooleanField
from wtforms.validators import DataRequired


class RegisterForm(FlaskForm):

    Aname = StringField('Имя Фамилия', validators=[DataRequired()])
    Astatus = StringField('Статус', validators=[DataRequired()])
    Alogin = StringField('Логин', validators=[DataRequired()])
    Apassword = PasswordField('Пароль', validators=[DataRequired()])
    Apassword_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    submit = SubmitField('Добавить')


class LoginForm(FlaskForm):

    Alogin = StringField('Логин', validators=[DataRequired()])
    Apassword = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class API_Key(FlaskForm):

    Key = PasswordField('Ключ', validators=[DataRequired()])
    submit = SubmitField('Далее')