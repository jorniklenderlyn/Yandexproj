from requests import post, get
import re
import random
import time

ret = ['SpongeBob', 'Смешарики - От винта', 'Billie Eilish - Bad Gay', 'Смешарики - Oт винта', 'Тима Белорусских - Незабудка']
i = 0
while True:
    try:
        res = get("https://docs.google.com/forms/d/e/1FAIpQLSd9vYm5l9rIqE8EbfI1VWIiWAQc2zmcwyI87Kbm9ntNq01rdQ/viewform")

        text = re.search('name="fbzx" value="(.*)">', res.text).group(1)

        ind = text.index('"')

        fbzx = int(text[:ind])
        name = random.choice(ret)
        json = {
            "entry.1888091466.other_option_response": name,
            "entry.1888091466": "__other_option__",
            "entry.1888091466_sentinel": "",
            "draftResponse": '[,,"' + str(fbzx) + '"]',
            "pageHistory": '0',
            "fbzx": str(fbzx)
        }

        headers = {
            'referer': f"https://docs.google.com/forms/d/e/1FAIpQLSd9vYm5l9rIqE8EbfI1VWIiWAQc2zmcwyI87Kbm9ntNq01rdQ/viewform?fbzx={fbzx}"
        }

        res = post(
            "https://docs.google.com/forms/d/e/1FAIpQLSd9vYm5l9rIqE8EbfI1VWIiWAQc2zmcwyI87Kbm9ntNq01rdQ/formResponse",
            data=json, headers=headers)
        i += 1
        print(f"{i}: {name}")
    except:
        print('ERROR')
        time.sleep(10)
