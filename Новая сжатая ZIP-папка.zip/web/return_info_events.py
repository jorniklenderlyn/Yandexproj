from requests import get

print(get('http://localhost:5000/api/key=***/events').json())

event_id = input('ID нужного события: ')
print(get(f'http://localhost:5000/api/key=***/events/{event_id}').json())

event_range = input('Диапазон нужного события: ')
print(get(f'http://localhost:5000/api/key=***/events/{event_range}').json())


