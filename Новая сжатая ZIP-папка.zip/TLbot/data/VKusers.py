import sqlalchemy
from .db_session import SqlAlchemyBase


class VKuser(SqlAlchemyBase):
    __tablename__ = "Vkusers"

    id = sqlalchemy.Column(sqlalchemy.Integer, autoincrement=True, primary_key=True)
    Uvk_id = sqlalchemy.Column(sqlalchemy.Text)
    Uclass = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Uclass_profile = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Uitcube_section = sqlalchemy.Column(sqlalchemy.Text, nullable=True)
    Umailing_schedule = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
    Umailing_events = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
