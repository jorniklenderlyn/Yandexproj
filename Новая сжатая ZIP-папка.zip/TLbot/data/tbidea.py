import sqlalchemy
from .db_session import SqlAlchemyBase


class Idea(SqlAlchemyBase):
    __tablename__ = "Idea"

    id = sqlalchemy.Column(sqlalchemy.Integer, autoincrement=True, primary_key=True)
    Iid = sqlalchemy.Column(sqlalchemy.Text)
    Imsger = sqlalchemy.Column(sqlalchemy.Text)
    Itext = sqlalchemy.Column(sqlalchemy.Text)
