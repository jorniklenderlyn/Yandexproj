qwe = ['qw23e', 'ldsjkfhhl324hjklh', 'lkd0', '99']


def get_new_url(qwe):
    lst = []
    for i in qwe:
        num = ''
        for j in i.split('/')[-1]:
            if j.isdigit():
                num += j
            elif num != '':
                break
        try:
            lst.append((int(num), i))
        except Exception:
            pass
    lst.sort()
    if lst[-1][0] - lst[0][0] > 20:
        return lst[0][1]
    return lst[-1][1]


print(get_new_url(qwe))